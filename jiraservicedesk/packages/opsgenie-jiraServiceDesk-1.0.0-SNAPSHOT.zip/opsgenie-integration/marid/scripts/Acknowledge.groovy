logger.warn("Alert with id [${alert.alertId}] is acknowledged by [${alert.username}] via ${source}");
return;