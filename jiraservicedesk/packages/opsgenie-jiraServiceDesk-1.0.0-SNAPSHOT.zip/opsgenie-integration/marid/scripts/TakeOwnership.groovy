logger.warn("""The ownership of the alert with id [${alert.alertId}] is taken by [${alert.username}] via ${source}""");
return;