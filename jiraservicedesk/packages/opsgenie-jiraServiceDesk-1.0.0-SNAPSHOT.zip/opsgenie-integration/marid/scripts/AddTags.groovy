logger.warn("Alert Add Tags: AlertId:[${alert.alertId}] Tags:[${alert.tags}] AddedTags:[${alert.addedTags}] via ${source}");
return;