logger.warn("Alert Note: AlertId:[${alert.alertId}] Note:[${alert.note}]  via ${source}");
return;