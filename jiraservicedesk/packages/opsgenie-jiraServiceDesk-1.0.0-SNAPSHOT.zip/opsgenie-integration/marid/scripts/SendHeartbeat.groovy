logger.debug("sending heartbeat with params:${params}")
opsgenie.heartbeat(params)