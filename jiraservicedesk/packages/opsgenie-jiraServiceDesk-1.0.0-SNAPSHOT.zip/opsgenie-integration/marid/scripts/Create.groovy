logger.warn("A new alert is created with id [${alert.alertId}]  via ${source}");
return;