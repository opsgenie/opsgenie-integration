logger.warn("Alert with id [${alert.alertId}] is unacknowledged by [${alert.username}] via ${source}");
return;