logger.warn("Alert Remove Tags: AlertId:[${alert.alertId}] Tags:[${alert.tags}] AddedTags:[${alert.removedTags}] via ${source}");
return;