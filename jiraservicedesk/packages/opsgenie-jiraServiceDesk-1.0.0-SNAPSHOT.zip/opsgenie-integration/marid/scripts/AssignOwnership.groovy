logger.warn("The ownership of the alert with id [${alert.alertId}] is assigned to [${alert.owner}]  via ${source}");
return;