logger.warn("Alert [${alert.alertId}] is closed  via ${source}");
return;