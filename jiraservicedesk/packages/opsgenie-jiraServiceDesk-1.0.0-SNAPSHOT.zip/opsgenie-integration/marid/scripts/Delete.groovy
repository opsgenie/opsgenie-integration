logger.warn("Alert [${alert.alertId}] is deleted  via ${source}");
return;