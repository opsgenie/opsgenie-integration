Please visit our Splunk ITSI Integration documentation (https://docs.opsgenie.com/v1.0/docs/splunk-it-service-intelligence-integration).
